package com.adriano.proj_heroko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjHerokoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjHerokoApplication.class, args);
	}

}
