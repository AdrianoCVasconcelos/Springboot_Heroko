package com.adriano.proj_heroko;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjHerokoApplicationTests {

	@Test
	void contextLoads() {
	}

}
